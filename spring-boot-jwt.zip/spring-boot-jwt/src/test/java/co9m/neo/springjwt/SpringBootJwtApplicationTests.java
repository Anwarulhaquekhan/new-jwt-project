package co9m.neo.springjwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
